import React, { useState, useEffect, useRef, useMemo } from 'react';
import proj4 from 'proj4';
import JSZip from 'jszip';
import { 
  MapPin, Layers, Settings, FileText, Download, Plus, Trash2, 
  ZoomIn, ZoomOut, Maximize2, AlertCircle, CheckCircle, Info, Menu, X,
  FolderOpen, Sliders, BarChart3, FileSpreadsheet, Compass, Sun, Moon, Upload, Save, Eye
} from 'lucide-react';

// --- Sample Data ---
const SAMPLE_JSON = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": {"Name": "Beerta xuduudka"},
      "geometry": {
        "type": "LineString",
        "coordinates": [
          [44.060598, 9.62233], [44.06061, 9.62235], [44.06062, 9.62236], [44.060625, 9.622378],
          [44.060623, 9.622397], [44.060605, 9.62241], [44.0597, 9.621482], [44.060683, 9.622347]
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {"Name": "Block tusaale (tu)"},
      "geometry": {
        "type": "Polygon",
        "coordinates": [
          [
            [44.059579, 9.622599], [44.060321, 9.622936], [44.060133, 9.623326], [44.059387, 9.622983],
            [44.059568, 9.622591], [44.060329, 9.620916], [44.059453, 9.620501], [44.059632, 9.620136],
            [44.060373, 9.620494], [44.060205, 9.620863], [44.059452, 9.622535], [44.059579, 9.622599]
          ]
        ]
      }
    }
  ]
};

// --- Geometry & GIS Helpers ---
function toItems(json: any) {
  let out: any[] = [], feats: any[] = [];
  if (json.type === 'FeatureCollection') feats = json.features || [];
  else if (json.type === 'Feature') feats = [json];
  else if (json.type) feats = [{ type: 'Feature', properties: {}, geometry: json }];
  
  feats.forEach((f, i) => {
    let g = f.geometry; if (!g) return;
    let nm = (f.properties && (f.properties.Name || f.properties.name)) || ('Feature ' + (i + 1));
    let add = (type: string, coords: any[], suffix = '') => {
      if (coords && coords.length >= 3) {
        out.push({ name: nm + suffix, type: type, coords: coords.map((c: any) => [c[0], c[1]]) });
      }
    };
    if (g.type === 'Polygon') add('Polygon', g.coordinates[0]);
    else if (g.type === 'MultiPolygon') g.coordinates.forEach((p: any, k: number) => add('Polygon', p[0], ' #' + (k + 1)));
    else if (g.type === 'LineString') add('Line', g.coordinates);
    else if (g.type === 'MultiLineString') g.coordinates.forEach((l: any, k: number) => add('Line', l, ' #' + (k + 1)));
  });
  return out;
}

function mdist(a: number[], b: number[]) {
  let dx = (a[0] - b[0]) * 111320 * Math.cos(a[1] * Math.PI / 180), dy = (a[1] - b[1]) * 110574;
  return Math.hypot(dx, dy);
}

function subRings(c: number[][]) {
  let rings: number[][][] = [], s = 0, n = c.length;
  while (s < n - 2) {
    let k = -1;
    for (let j = s + 3; j < n; j++) {
      if (mdist(c[j], c[s]) < 2.5) { k = j; break; }
    }
    if (k < 0) {
      if (n - s >= 4) rings.push(c.slice(s));
      break;
    }
    rings.push(c.slice(s, k));
    s = k + 1;
  }
  return rings;
}

function buildCandidates(items: any[]) {
  let cands: any[] = [];
  items.forEach((it) => {
    if (it.type !== 'Polygon') return;
    let rs = subRings(it.coords);
    rs.forEach((r, i) => {
      if (r.length >= 4) {
        cands.push({ label: it.name + (rs.length > 1 ? (' · qayb ' + (i + 1)) : '') + ' (' + r.length + ' geesood)', ring: r });
      }
    });
  });
  return cands;
}

function shoelace(r: number[][]) {
  let a = 0;
  for (let i = 0; i < r.length; i++) {
    let p = r[i], q = r[(i + 1) % r.length];
    a += p[0] * q[1] - q[0] * p[1];
  }
  return a / 2;
}

function pip(pt: number[], ring: number[][]) {
  let x = pt[0], y = pt[1], c = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    let a = ring[i], b = ring[j];
    if ((a[1] > y) !== (b[1] > y) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
  }
  return c;
}

function cr(a: number[], b: number[], c: number[]) {
  return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
}

function segX(p1: number[], p2: number[], p3: number[], p4: number[]) {
  let d1 = cr(p3, p4, p1), d2 = cr(p3, p4, p2), d3 = cr(p1, p2, p3), d4 = cr(p1, p2, p4);
  return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0));
}

function hull(pts: number[][]) {
  pts = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  let lo: number[][] = [], up: number[][] = [];
  for (let i = 0; i < pts.length; i++) {
    while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], pts[i]) <= 0) lo.pop();
    lo.push(pts[i]);
  }
  for (let i = pts.length - 1; i >= 0; i--) {
    while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], pts[i]) <= 0) up.pop();
    up.push(pts[i]);
  }
  up.pop(); lo.pop();
  return lo.concat(up);
}

function minRect(pts: number[][]) {
  let h = hull(pts), best: any = null;
  for (let i = 0; i < h.length; i++) {
    let a = h[i], b = h[(i + 1) % h.length], dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy);
    if (!l) continue;
    dx /= l; dy /= l;
    let u0 = 1e18, u1 = -1e18, v0 = 1e18, v1 = -1e18;
    h.forEach(p => {
      let u = p[0] * dx + p[1] * dy, v = -p[0] * dy + p[1] * dx;
      u0 = Math.min(u0, u); u1 = Math.max(u1, u); v0 = Math.min(v0, v); v1 = Math.max(v1, v);
    });
    let A = (u1 - u0) * (v1 - v0);
    if (!best || A < best.A) {
      let cu = (u0 + u1) / 2, cv = (v0 + v1) / 2;
      best = { A: A, dx: dx, dy: dy, w: u1 - u0, h: v1 - v0, c: [cu * dx - cv * dy, cu * dy + cv * dx] };
    }
  }
  let d = best.w >= best.h ? [best.dx, best.dy] : [-best.dy, best.dx];
  return { u: d, c: best.c, long: Math.max(best.w, best.h), short: Math.min(best.w, best.h) };
}

function frameFromRing(P: number[][]) {
  let n = P.length;
  if (n === 4) {
    let e = [0, 1, 2, 3].map(i => { let q = P[(i + 1) % 4], p = P[i]; return [q[0] - p[0], q[1] - p[1]]; });
    let L = e.map(v => Math.hypot(v[0], v[1]));
    let idx = [0, 1, 2, 3].sort((a, b) => L[b] - L[a]).slice(0, 2), s = [0, 0];
    idx.forEach(i => { let x = e[i][0] / L[i], y = e[i][1] / L[i]; if (x < 0 || (x === 0 && y < 0)) { x = -x; y = -y; } s[0] += x; s[1] += y; });
    let m = Math.hypot(s[0], s[1]);
    let sides = L.slice().sort((a, b) => b - a);
    return { u: [s[0] / m, s[1] / m], c: [(P[0][0] + P[1][0] + P[2][0] + P[3][0]) / 4, (P[0][1] + P[1][1] + P[2][1] + P[3][1]) / 4], long: (sides[0] + sides[1]) / 2, short: (sides[2] + sides[3]) / 2 };
  }
  return minRect(P);
}

function ringArea(r: number[][]) { return Math.abs(shoelace(r)); }
function ccw(r: number[][]) { return shoelace(r) < 0 ? r.slice().reverse() : r; }

function crossPt(a: number[], b: number[], c: number[], d: number[]) {
  let d1 = cr(c, d, a), d2 = cr(c, d, b), d3 = cr(a, b, c), d4 = cr(a, b, d);
  if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) {
    let t = d1 / (d1 - d2);
    return { t: t, p: [a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])] };
  }
  return null;
}

function splitEdges(A: number[][], B: number[][]) {
  let out: any[] = [], n = A.length, m = B.length;
  for (let i = 0; i < n; i++) {
    let a = A[i], b = A[(i + 1) % n], xs: any[] = [];
    for (let j = 0; j < m; j++) {
      let x = crossPt(a, b, B[j], B[(j + 1) % m]);
      if (x) xs.push(x);
    }
    xs.sort((u, v) => u.t - v.t);
    let prev = a;
    xs.forEach(x => { out.push([prev, x.p]); prev = x.p; });
    out.push([prev, b]);
  }
  return out;
}

function chainSegs(segs: any[]) {
  let key = (p: number[]) => p[0].toFixed(5) + ',' + p[1].toFixed(5), mp: any = {}, rings: number[][][] = [];
  segs.forEach(s => { let k = key(s[0]); (mp[k] = mp[k] || []).push(s); });
  segs.forEach(s => {
    if (s.u) return;
    let ring: number[][] = [], cur = s, last = s;
    while (cur) {
      cur.u = 1; ring.push(cur[0]); last = cur;
      let nx = (mp[key(cur[1])] || []).filter((z: any) => !z.u);
      cur = nx[0];
    }
    if (ring.length >= 3 && key(last[1]) === key(ring[0])) rings.push(ring);
  });
  return rings;
}

function boolRings(A: number[][], B: number[][], op: string) {
  A = ccw(A); B = ccw(B);
  let mid = (e: number[][]) => [(e[0][0] + e[1][0]) / 2, (e[0][1] + e[1][1]) / 2], segs: any[] = [];
  splitEdges(A, B).forEach(e => { let inB = pip(mid(e), B); if (op === 'and' ? inB : !inB) segs.push(e); });
  splitEdges(B, A).forEach(e => { if (pip(mid(e), A)) segs.push(op === 'and' ? e : [e[1], e[0]]); });
  return chainSegs(segs);
}

// Minimal dbf & shp helper
function dbf(fields: any[], rows: any[][]) {
  let enc = new TextEncoder(), nf = fields.length, hl = 32 + 32 * nf + 1, rl = 1 + fields.reduce((a, f) => a + f.len, 0);
  let buf = new Uint8Array(hl + rl * rows.length + 1), dv = new DataView(buf.buffer), d = new Date();
  buf[0] = 3; buf[1] = d.getFullYear() - 1900; buf[2] = d.getMonth() + 1; buf[3] = d.getDate();
  dv.setUint32(4, rows.length, true); dv.setUint16(8, hl, true); dv.setUint16(10, rl, true);
  fields.forEach((f, i) => {
    let o = 32 + 32 * i;
    enc.encode(f.name.slice(0, 10)).forEach((b, k) => { buf[o + k] = b; });
    buf[o + 11] = f.type.charCodeAt(0); buf[o + 16] = f.len; buf[o + 17] = f.dec || 0;
  });
  buf[32 + 32 * nf] = 0x0D;
  rows.forEach((row, ri) => {
    let o = hl + ri * rl; buf[o] = 0x20; o++;
    fields.forEach((f, i) => {
      let v = row[i], bytes;
      if (f.type === 'N') {
        let s = (v == null ? '' : Number(v).toFixed(f.dec || 0)).padStart(f.len, ' ').slice(-f.len);
        bytes = enc.encode(s);
      } else {
        bytes = enc.encode(String(v == null ? '' : v)).slice(0, f.len);
      }
      buf.set(bytes, o);
      if (f.type !== 'N') { for (let k = bytes.length; k < f.len; k++) buf[o + k] = 0x20; }
      o += f.len;
    });
  });
  buf[buf.length - 1] = 0x1A;
  return buf;
}

function shp(rings: number[][][]) {
  let recs = rings.map(rg => {
    let r = rg.slice();
    if (r[0][0] !== r[r.length - 1][0] || r[0][1] !== r[r.length - 1][1]) r.push(r[0]);
    let a = 0; for (let i = 0; i < r.length - 1; i++) a += r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1];
    if (a > 0) r.reverse();
    return r;
  });
  let total = 100, bbox = [1e18, 1e18, -1e18, -1e18];
  recs.forEach(r => {
    total += 8 + 44 + 4 + 16 * r.length;
    r.forEach(q => { bbox = [Math.min(bbox[0], q[0]), Math.min(bbox[1], q[1]), Math.max(bbox[2], q[0]), Math.max(bbox[3], q[1])]; });
  });
  let sb = new ArrayBuffer(total), sv = new DataView(sb), xb = new ArrayBuffer(100 + 8 * recs.length), xv = new DataView(xb);
  [[sv, total], [xv, 100 + 8 * recs.length]].forEach(a => {
    let v: DataView = a[0] as DataView;
    v.setInt32(0, 9994); v.setInt32(24, (a[1] as number) / 2); v.setInt32(28, 1000, true); v.setInt32(32, 5, true);
    v.setFloat64(36, bbox[0], true); v.setFloat64(44, bbox[1], true); v.setFloat64(52, bbox[2], true); v.setFloat64(60, bbox[3], true);
  });
  let o = 100;
  recs.forEach((r, i) => {
    let cl = 44 + 4 + 16 * r.length, bx = [1e18, 1e18, -1e18, -1e18];
    r.forEach(q => { bx = [Math.min(bx[0], q[0]), Math.min(bx[1], q[1]), Math.max(bx[2], q[0]), Math.max(bx[3], q[1])]; });
    xv.setInt32(100 + 8 * i, o / 2); xv.setInt32(104 + 8 * i, cl / 2);
    sv.setInt32(o, i + 1); sv.setInt32(o + 4, cl / 2); o += 8;
    sv.setInt32(o, 5, true); sv.setFloat64(o + 4, bx[0], true); sv.setFloat64(o + 12, bx[1], true); sv.setFloat64(o + 20, bx[2], true); sv.setFloat64(o + 28, bx[3], true);
    sv.setInt32(o + 36, 1, true); sv.setInt32(o + 40, r.length, true); sv.setInt32(o + 44, 0, true); o += 48;
    r.forEach(q => { sv.setFloat64(o, q[0], true); sv.setFloat64(o + 8, q[1], true); o += 16; });
  });
  return { shp: new Uint8Array(sb), shx: new Uint8Array(xb) };
}

const PRJ_WGS = 'GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]';
function prjUtm(r: any) {
  return 'PROJCS["WGS_1984_UTM_Zone_' + r.zone + (r.south ? 'S' : 'N') + '",' + PRJ_WGS + ',PROJECTION["Transverse_Mercator"],PARAMETER["False_Easting",500000.0],PARAMETER["False_Northing",' + (r.south ? '10000000.0' : '0.0') + '],PARAMETER["Central_Meridian",' + (r.zone * 6 - 183) + '.0],PARAMETER["Scale_Factor",0.9996],PARAMETER["Latitude_Of_Origin",0.0],UNIT["Meter",1.0]]';
}

export default function App() {
  const [items, setItems] = useState<any[]>([]);
  const [cands, setCands] = useState<any[]>([]);
  const [areas, setAreas] = useState<any[]>([]);
  const [selB, setSelB] = useState<number>(0);
  const [selS, setSelS] = useState<number>(0);
  const [sCustom, setSCustom] = useState<boolean>(false);
  
  // Parameters
  const [bL, setBL] = useState<number>(90);
  const [bW, setBW] = useState<number>(48);
  const [pW, setPW] = useState<number>(18);
  const [pD, setPD] = useState<number>(24);
  const [rU, setRU] = useState<number>(15);
  const [rV, setRV] = useState<number>(15);
  const [rLink, setRLink] = useState<boolean>(true);
  const [aRot, setARot] = useState<number>(0);
  const [aMin, setAMin] = useState<number>(1);
  const [aSu, setASu] = useState<number>(0);
  const [aSv, setASv] = useState<number>(0);
  const [aSwap, setASwap] = useState<boolean>(false);
  
  const [roads, setRoads] = useState<any[]>([]);
  const [specialRoadAxis, setSpecialRoadAxis] = useState<string>('R');
  const [specialRoadIndex, setSpecialRoadIndex] = useState<number>(0);
  const [specialRoadWidth, setSpecialRoadWidth] = useState<number>(25);

  const [tB, setTB] = useState<boolean>(true);
  const [tP, setTP] = useState<boolean>(false);
  
  // 3 Main Pages Co-housing the Full Functionality: 'map' (Khariirad), 'nashqado' (Nashqado/Kayd), 'setting' (Setting)
  const [page, setPage] = useState<string>('map');
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [info, setInfo] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [exportMenuOpen, setExportMenuOpen] = useState<boolean>(false);
  const [showImportModal, setShowImportModal] = useState<boolean>(false);
  const [pendingFileName, setPendingFileName] = useState<string>('');

  // Load sample on mount
  useEffect(() => {
    useSampleData();
  }, []);

  const useSampleData = () => {
    setSCustom(false);
    setAreas([]);
    setRoads([]);
    let its = toItems(SAMPLE_JSON);
    setItems(its);
    let bi = 0, bs = -1;
    its.forEach((it, i) => { let s = (it.type === 'Line' ? 1e6 : 0) + it.coords.length; if (s > bs) { bs = s; bi = i; } });
    setSelB(bi);
    let candList = buildCandidates(its.filter((_, i) => i !== bi));
    setCands(candList);
    setSelS(0);
  };

  const handleFileLoad = (file: File) => {
    let rd = new FileReader();
    rd.onload = () => {
      try {
        let j = JSON.parse(rd.result as string), its = toItems(j);
        if (!its.length) throw new Error('Geometry ma jirto');
        setItems(its);
        let candList = buildCandidates(its);
        setCands(candList);
        setPendingFileName(file.name);
        setShowImportModal(true);
      } catch (err: any) {
        alert('File-ka lama akhrin karo: ' + err.message);
      }
    };
    rd.readAsText(file);
  };

  const addSpecialRoad = () => {
    setRoads([...roads, { axis: specialRoadAxis, j: specialRoadIndex, w: specialRoadWidth }]);
  };

  // Computation
  const result = useMemo(() => {
    if (!items.length || selB >= items.length) return null;
    let B = items[selB];
    let C = cands[selS];
    let p = { L: bL, W: bW, pw: pW, pd: pD, rU: rU, rV: rV, rot: aRot, minP: Math.max(1, Math.round(aMin) || 1), su: aSu, sv: aSv, swap: aSwap };
    
    if (!B) return null;
    let ring = B.coords.slice();
    if (ring.some((c: number[]) => !isFinite(c[0]) || !isFinite(c[1]) || Math.abs(c[0]) > 180 || Math.abs(c[1]) > 90)) return null;
    let last = ring[ring.length - 1], first = ring[0];
    if (last[0] === first[0] && last[1] === first[1]) ring.pop();
    
    let cLon = 0, cLat = 0;
    ring.forEach((q: number[]) => { cLon += q[0]; cLat += q[1]; });
    cLon /= ring.length; cLat /= ring.length;
    let zone = Math.max(1, Math.min(60, Math.floor((cLon + 180) / 6) + 1)), south = cLat < 0;
    let def = '+proj=utm +zone=' + zone + (south ? ' +south' : '') + ' +datum=WGS84 +units=m +no_defs';
    let fwd = (c: number[]) => proj4('EPSG:4326', def, [c[0], c[1]]);
    let inv = (x: number[]) => proj4(def, 'EPSG:4326', [x[0], x[1]]);
    let bring = ring.map(fwd);
    let barea = Math.abs(shoelace(bring));
    let bb = [1e18, 1e18, -1e18, -1e18];
    bring.forEach(q => { bb = [Math.min(bb[0], q[0]), Math.min(bb[1], q[1]), Math.max(bb[2], q[0]), Math.max(bb[3], q[1])]; });
    
    let res: any = { zone, south, def, inv, fwd, bring, barea, bperim: 0, bb, params: p, blocks: [], plots: [], allPlots: [], halves: [], halvesCounted: [], sample: null, warn: [] };
    for (let i = 0; i < bring.length; i++) res.bperim += Math.hypot(bring[i][0] - bring[(i + 1) % bring.length][0], bring[i][1] - bring[(i + 1) % bring.length][1]);
    
    let gap = mdist(B.coords[0], B.coords[B.coords.length - 1]);
    if (gap > 0.5) res.warn.push('Xuduudka lama xirin: bilowga iyo dhammaadka waxay u dhexeeyaan ' + gap.toFixed(1) + ' m.');

    if (!C || p.L <= 0 || p.W <= 0 || p.pw <= 0 || p.pd <= 0) return res;

    let sring = C.ring.map(fwd);
    if (Math.hypot(sring[0][0] - sring[sring.length - 1][0], sring[0][1] - sring[sring.length - 1][1]) < 2.5) sring.pop();
    let fr = frameFromRing(sring);
    let ux = fr.u[0], uy = fr.u[1];
    let a = (p.rot * Math.PI / 180), ca = Math.cos(a), sa = Math.sin(a);
    let nx = ux * ca - uy * sa, ny = ux * sa + uy * ca; ux = nx; uy = ny;
    if (p.swap) { let t = ux; ux = -uy; uy = t; }
    if (ux < 0 || (Math.abs(ux) < 1e-12 && uy < 0)) { ux = -ux; uy = -uy; }
    let vx = -uy, vy = ux; if (vy < 0) { vx = -vx; vy = -vy; }
    let c0 = [fr.c[0] + p.su * ux + p.sv * vx, fr.c[1] + p.su * uy + p.sv * vy];
    res.u = [ux, uy]; res.v = [vx, vy]; res.c0 = c0; res.angle = Math.atan2(uy, ux) * 180 / Math.PI;
    res.sample = { ring: sring, long: fr.long, short: fr.short };

    let SU = p.L + p.rU, SV = p.W + p.rV, spR: any = {}, spC: any = {}, dU = 0, dV = 0;
    roads.forEach(z => { if (z.axis === 'R') { spR[z.j] = z.w; dV += Math.abs(z.w - p.rV); } else { spC[z.j] = z.w; dU += Math.abs(z.w - p.rU); } });
    let off = (k: number, sp: any, defW: number) => {
      let o = 0, j;
      if (k > 0) { for (j = 0; j < k; j++) o += (sp[j] !== undefined ? sp[j] : defW) - defW; }
      else { for (j = k; j < 0; j++) o -= (sp[j] !== undefined ? sp[j] : defW) - defW; }
      return o;
    };
    let cuOf = (i: number) => i * SU + off(i, spC, p.rU), cvOf = (j: number) => j * SV + off(j, spR, p.rV);
    let P = (cu: number, cv: number) => [c0[0] + cu * ux + cv * vx, c0[1] + cu * uy + cv * vy];
    let rect = (cu: number, cv: number, l: number, w: number) => [P(cu - l / 2, cv - w / 2), P(cu + l / 2, cv - w / 2), P(cu + l / 2, cv + w / 2), P(cu - l / 2, cv + w / 2)];

    let us = [1e18, -1e18], vs = [1e18, -1e18];
    bring.forEach(q => {
      let du = q[0] - c0[0], dv = q[1] - c0[1], pu = du * ux + dv * uy, pv = du * vx + dv * vy;
      us = [Math.min(us[0], pu), Math.max(us[1], pu)]; vs = [Math.min(vs[0], pv), Math.max(vs[1], pv)];
    });
    let ci0 = Math.floor(us[0] / SU) - 1, ci1 = Math.ceil(us[1] / SU) + 1, rj0 = Math.floor(vs[0] / SV) - 1, rj1 = Math.ceil(vs[1] / SV) + 1;
    let nC = Math.floor(p.L / p.pw + 1e-9), nR = Math.floor(p.W / p.pd + 1e-9);
    if (nC < 1 || nR < 1) return res;

    let EPS = 1e-4, TOL = 1e-3;
    let shrink = (rc: number[][], e: number) => {
      let cx = 0, cy = 0; rc.forEach(q => { cx += q[0] / 4; cy += q[1] / 4; });
      return rc.map(q => { let dx = cx - q[0], dy = cy - q[1], l = Math.hypot(dx, dy) || 1; return [q[0] + dx / l * e, q[1] + dy / l * e]; });
    };
    let clipInfo = (rc: number[][], rg = bring) => {
      let sh = shrink(rc, EPS), total = ringArea(rc), ins = boolRings(sh, rg, 'and'), inA = 0;
      ins.forEach(z => { inA += ringArea(z); });
      if (inA <= TOL) return { st: 'outside', inside: [], outside: [rc], inA: 0, outA: total, total };
      if (inA >= ringArea(sh) - TOL) return { st: 'full', inside: [rc], outside: [], inA: total, outA: 0, total };
      return { st: 'partial', inside: ins, outside: boolRings(sh, rg, 'diff'), inA, outA: Math.max(0, total - inA), total };
    };

    let halfOK = (hr: number[][], hl: number, hw: number) => {
      let e0 = Math.hypot(hr[1][0] - hr[0][0], hr[1][1] - hr[0][1]), e1 = Math.hypot(hr[3][0] - hr[0][0], hr[3][1] - hr[0][1]);
      return Math.abs(e0 - hl) < 0.01 && Math.abs(e1 - hw) < 0.01 && Math.abs(ringArea(hr) - p.pw * p.pd / 2) < 0.01;
    };

    let raw: any[] = [], pad = String(nR * nC).length > 1 ? 2 : 1;
    if (nR * nC >= 100) pad = 3;

    for (let ci = ci0; ci <= ci1; ci++) {
      for (let rj = rj0; rj <= rj1; rj++) {
        let cu = cuOf(ci), cv = cvOf(rj), blk = rect(cu, cv, p.L, p.W);
        let bx = blk.map(q => q[0]), by = blk.map(q => q[1]);
        if (Math.max(...bx) < bb[0] || Math.min(...bx) > bb[2] || Math.max(...by) < bb[1] || Math.min(...by) > bb[3]) continue;
        let plots: any[] = [], nf = 0, nh = 0, no = 0;
        for (let rr = 0; rr < nR; rr++) {
          for (let cc = 0; cc < nC; cc++) {
            let pcu = cu - p.L / 2 + p.pw * (cc + .5), pcv = cv + p.W / 2 - p.pd * (rr + .5), pr = rect(pcu, pcv, p.pw, p.pd);
            let pci = clipInfo(pr), st = pci.st;
            let q: any = { no: rr * nC + cc + 1, r: rr + 1, c: cc + 1, rect: pr, status: st, full: st === 'full', inGeom: pci.inside, outGeom: pci.outside, inArea: pci.inA, outArea: pci.outA, halves: [], nHalf: 0, reason: '' };
            if (st === 'full') nf++;
            else if (st === 'outside') { no++; q.reason = 'Plot-ku gebi ahaanba xuduudka ka baxay'; }
            else {
              let side = (cc === 0 || cc === nC - 1), hl = side ? p.pw : p.pw / 2, hw = side ? p.pd / 2 : p.pd;
              for (let k = 0; k < 2; k++) {
                let sg = k === 0 ? 1 : -1, hr = side ? rect(pcu, pcv + sg * hw / 2, hl, hw) : rect(pcu - sg * hl / 2, pcv, hl, hw);
                let hi = clipInfo(hr), hs = hi.st, ok = pci.st === 'partial' && halfOK(hr, hl, hw);
                q.halves.push({ n: k + 1, rect: hr, status: hs, counted: hs === 'full' && ok, valid: ok, inGeom: hi.inside, outGeom: hi.outside, inArea: hi.inA, outArea: hi.outA, w: hl, d: hw, area: hl * hw, reason: '' });
              }
              q.nHalf = q.halves.filter((z: any) => z.counted).length; nh += q.nHalf;
              q.reason = q.nHalf ? 'Plot-ka asalka ah lama tiriyo; waxaa la tiriyay ' + q.nHalf + ' half-plot' : 'Qayb ahaan gudaha ayuu yahay';
            }
            plots.push(q);
          }
        }
        raw.push({ ci, rj, rect: blk, plots, nf, nh, total: nC * nR, status: nf === nC * nR ? 'full' : (no === nC * nR ? 'outside' : 'partial') });
      }
    }

    let base = raw.filter(b => b.nf >= p.minP); if (!base.length) base = raw;
    let rjs: number[] = [], cis: number[] = [];
    base.forEach(b => { if (rjs.indexOf(b.rj) < 0) rjs.push(b.rj); if (cis.indexOf(b.ci) < 0) cis.push(b.ci); });
    rjs.sort((x, y) => y - x); cis.sort((x, y) => x - y);
    
    let mapIdx = (v: number, arr: number[], desc: boolean) => {
      let i = arr.indexOf(v); if (i >= 0) return i + 1;
      let f = arr[0], l = arr[arr.length - 1];
      if (desc ? (v > f) : (v < f)) return 1 - Math.abs(v - f);
      if (desc ? (v < l) : (v > l)) return arr.length + Math.abs(v - l);
      return 1 + Math.abs(v - f);
    };

    raw.forEach(b => {
      b.R = mapIdx(b.rj, rjs, true); b.C = mapIdx(b.ci, cis, false); b.id = 'R' + b.R + '-C' + b.C;
      b.plots.forEach((q: any) => {
        q.id = b.id + '-P' + String(q.no).padStart(pad, '0'); q.block = b.id;
        q.halves.forEach((x: any) => { x.id = q.id + '-H' + x.n; x.block = b.id; x.parent = q.id; x.pno = q.no; });
      });
    });

    raw.sort((x, y) => x.R - y.R || x.C - y.C);
    res.nOutPlots = 0;
    raw.forEach(b => { b.plots.forEach((q: any) => { if (q.status === 'outside') res.nOutPlots++; }); });
    raw.forEach(b => { b.plots = b.plots.filter((q: any) => q.full || q.nHalf > 0); });
    raw = raw.filter(b => b.plots.length > 0);
    res.blocks = raw;
    raw.forEach(b => {
      b.plots.forEach((q: any) => {
        res.allPlots.push(q); if (q.full) res.plots.push(q);
        q.halves.forEach((x: any) => { res.halves.push(x); if (x.counted) res.halvesCounted.push(x); });
      });
    });

    res.areas = areas.map(a => {
      let ar = a.coords.map(fwd);
      if (ar.length > 3 && Math.hypot(ar[0][0] - ar[ar.length - 1][0], ar[0][1] - ar[ar.length - 1][1]) < 0.01) ar.pop();
      return { name: a.name, ring: ar, area: Math.abs(shoelace(ar)), nP: 0, nH: 0, aP: 0, aH: 0 };
    });
    let inAreas = (rc: number[][]) => {
      for (let k = 0; k < res.areas.length; k++) { if (clipInfo(rc, res.areas[k].ring).st === 'full') return res.areas[k]; }
      return null;
    };
    res.plots.forEach((q: any) => { let A = inAreas(q.rect); if (A) { q.zone = A.name; A.nP++; A.aP += p.pw * p.pd; } });
    res.halvesCounted.forEach((x: any) => { let A = inAreas(x.rect); if (A) { x.zone = A.name; A.nH++; A.aH += x.area; } });

    res.sampleRect = rect(0, 0, p.L, p.W);
    res.sampleNote = { dL: fr.long - p.L, dW: fr.short - p.W };
    res.nR = nR; res.nC = nC; res.pad = pad;

    res.roadStrips = [];
    roads.forEach(z => {
      if (!(z.w > 0)) return;
      let A: any, lab: string, bl: any;
      if (z.axis === 'R') {
        let v0 = cvOf(z.j) + p.W / 2;
        A = [P(us[0] - SU, v0), P(us[1] + SU, v0), P(us[1] + SU, v0 + z.w), P(us[0] - SU, v0 + z.w)];
        bl = raw.filter(b => b.rj === z.j + 1)[0]; lab = bl ? ('R' + bl.R + '-R' + (bl.R + 1)) : ('rj' + z.j);
      } else {
        let u0 = cuOf(z.j) + p.L / 2;
        A = [P(u0, vs[0] - SV), P(u0 + z.w, vs[0] - SV), P(u0 + z.w, vs[1] + SV), P(u0, vs[1] + SV)];
        bl = raw.filter(b => b.ci === z.j)[0]; lab = bl ? ('C' + bl.C + '-C' + (bl.C + 1)) : ('ci' + z.j);
      }
      let pcs = boolRings(A, bring, 'and'), ar = 0;
      pcs.forEach(g => { ar += ringArea(g); });
      res.roadStrips.push({ axis: z.axis, j: z.j, w: z.w, label: lab, pieces: pcs, len: ar / z.w });
    });

    return res;
  }, [items, selB, selS, bL, bW, pW, pD, rU, rV, aRot, aMin, aSu, aSv, aSwap, roads, areas]);

  // SVG Mapping ViewBox & Pan/Zoom
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [vb, setVb] = useState<{ x: number; y: number; w: number; h: number } | null>(null);

  const fitBounds = () => {
    if (!result) return;
    let all = result.bring.concat(result.sample.ring).concat(result.sampleRect);
    let ox = (result.bb[0] + result.bb[2]) / 2, oy = (result.bb[1] + result.bb[3]) / 2;
    let X = (q: number[]) => q[0] - ox, Y = (q: number[]) => -(q[1] - oy);
    let x0 = 1e18, y0 = 1e18, x1 = -1e18, y1 = -1e18;
    all.forEach(q => { let x = X(q), y = Y(q); x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); });
    let padm = Math.max(x1 - x0, y1 - y0) * 0.05;
    setVb({ x: x0 - padm, y: y0 - padm, w: x1 - x0 + 2 * padm, h: y1 - y0 + 2 * padm });
  };

  useEffect(() => {
    if (result) fitBounds();
  }, [result?.bring]);

  const zoomMap = (factor: number) => {
    if (!vb) return;
    let nw = vb.w / factor, nh = vb.h / factor;
    setVb({ x: vb.x + (vb.w - nw) / 2, y: vb.y + (vb.h - nh) / 2, w: nw, h: nh });
  };

  // Export handlers
  const handleDownloadGeoJSON = () => {
    if (!result) return;
    let layers = layersOf(result);
    let gj = geojsonOf(result, layers);
    let blob = new Blob([JSON.stringify(gj.all, null, 2)], { type: 'application/json' });
    let url = URL.createObjectURL(blob);
    let a = document.createElement('a'); a.href = url; a.download = 'Beerta_Naqshad.json'; a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadShapefile = async (crs = 'wgs') => {
    if (!result) return;
    let zip = new JSZip();
    let layers = layersOf(result);
    shapefileZip(result, layers, crs, zip, '');
    let content = await zip.generateAsync({ type: 'blob' });
    let url = URL.createObjectURL(content);
    let a = document.createElement('a'); a.href = url; a.download = 'Beerta_Shapefile_' + crs + '.zip'; a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadAll = async () => {
    if (!result) return;
    let zip = new JSZip();
    let layers = layersOf(result);
    let gj = geojsonOf(result, layers);
    zip.file('Beerta_All_Layers.json', JSON.stringify(gj.all, null, 2));
    zip.file('Plots_List.csv', csvOf(result));
    let shpFolder = zip.folder('Shapefile_WGS84');
    if (shpFolder) shapefileZip(result, layers, 'wgs', shpFolder, '');
    let content = await zip.generateAsync({ type: 'blob' });
    let url = URL.createObjectURL(content);
    let a = document.createElement('a'); a.href = url; a.download = 'Beerta_Dhammaan_Xogta.zip'; a.click();
    URL.revokeObjectURL(url);
  };

  const layersOf = (r: any) => {
    let p = r.params;
    let L: any = {};
    L.Boundary_Beerta = [{ ring: r.bring, props: { Name: 'Beerta - xuduudka', Area_m2: +r.barea.toFixed(1) } }];
    let stl: any = { full: 'FULL', partial: 'PARTIALLY_OUTSIDE', outside: 'OUTSIDE' };
    let hst: any = { full: 'HALF_FULL', partial: 'PARTIALLY_OUTSIDE', outside: 'OUTSIDE' };
    let yn = (x: boolean) => x ? 'YES' : 'NO';
    L.Blocks = r.blocks.map((b: any) => ({ ring: b.rect, props: { Block_ID: b.id, Row: b.R, Col: b.C, Plots_full: b.nf, Status: stl[b.status] } }));
    L.Plots = r.allPlots.map((q: any) => ({ ring: q.rect, props: { Plot_ID: q.id, Block_ID: q.block, Status: stl[q.status], Counted: yn(q.full) } }));
    L.Half_Plots = r.halves.map((x: any) => ({ ring: x.rect, props: { Half_ID: x.id, Parent: x.parent, Status: hst[x.status], Counted: yn(x.counted) } }));
    return L;
  };

  const geojsonOf = (r: any, layers: any) => {
    let all: any[] = [], per: any = {};
    Object.keys(layers).forEach(k => {
      per[k] = layers[k].map((f: any) => {
        let ring = f.ring.map((q: number[]) => { let c = r.inv(q); return [+c[0].toFixed(8), +c[1].toFixed(8)]; });
        ring.push(ring[0]);
        return { type: 'Feature', properties: { Layer: k, ...f.props }, geometry: { type: 'Polygon', coordinates: [ring] } };
      });
      all = all.concat(per[k]);
    });
    return { all: { type: 'FeatureCollection', name: 'Beerta_all_layers', features: all } };
  };

  const csvOf = (r: any) => {
    let p = r.params, q = (v: any) => '"' + String(v).replace(/"/g, '""') + '"';
    let rows = ['Plot_ID,Block_ID,Plot_No,Width_m,Depth_m,Area_m2,Status'];
    r.allPlots.forEach((o: any) => { rows.push([o.id, o.block, o.no, p.pw, p.pd, (p.pw * p.pd).toFixed(1), o.status].join(',')); });
    return rows.join('\n');
  };

  const shapefileZip = (r: any, layers: any, crs: string, zip: any, folder: string) => {
    let f = folder ? zip.folder(folder) : zip;
    Object.keys(layers).forEach(k => {
      let feats = layers[k]; if (!feats.length) return;
      let sample = feats[0].props, keys = Object.keys(sample);
      let fields = keys.map(n => typeof sample[n] === 'number' ? { name: n, type: 'N', len: 16, dec: 3 } : { name: n, type: 'C', len: 100 });
      let rings = feats.map((ft: any) => crs === 'wgs' ? ft.ring.map((q: number[]) => r.inv(q)) : ft.ring);
      let s = shp(rings), rows = feats.map((ft: any) => keys.map(n => ft.props[n]));
      f.file(k + '.shp', s.shp); f.file(k + '.shx', s.shx); f.file(k + '.dbf', dbf(fields, rows));
      f.file(k + '.prj', crs === 'wgs' ? PRJ_WGS : prjUtm(r)); f.file(k + '.cpg', 'UTF-8');
    });
  };

  const svgContent = useMemo(() => {
    if (!result) return null;
    let ox = result.ox, oy = result.oy;
    let X = (q: number[]) => +(q[0] - ox).toFixed(2), Y = (q: number[]) => +(-(q[1] - oy)).toFixed(2);
    let pts = (rr: number[][]) => rr.map(q => X(q) + ',' + Y(q)).join(' ');
    
    let els: any[] = [];
    els.push(<polygon key="boundary-bg" points={pts(result.bring)} fill="rgba(10,106,106,0.04)" stroke="none" />);
    
    result.roadStrips.forEach((z: any, idx: number) => {
      z.pieces.forEach((g: number[][], pi: number) => {
        els.push(<polygon key={`road-${idx}-${pi}`} points={pts(g)} fill="rgba(230,126,34,0.25)" stroke="#e67e22" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />);
      });
    });

    result.blocks.forEach((b: any) => {
      b.plots.forEach((q: any) => {
        if (q.status === 'full') {
          els.push(<polygon key={q.id} points={pts(q.rect)} fill="white" stroke="#64748b" strokeWidth="0.6" vectorEffect="non-scaling-stroke" onClick={() => setInfo(`${q.id} · FULL · ${pW * pD} m²`)} className="cursor-pointer hover:fill-teal-50" />);
        } else if (q.status === 'partial') {
          els.push(<polygon key={q.id + '-in'} points={pts(q.rect)} fill="url(#hat)" stroke="#dc2626" strokeWidth="0.6" vectorEffect="non-scaling-stroke" onClick={() => setInfo(`${q.id} · PARTIAL · gudaha ${q.inArea.toFixed(1)} m²`)} className="cursor-pointer" />);
        }
      });
      let col = b.status === 'full' ? '#0a6a6a' : (b.status === 'outside' ? '#64748b' : '#dc2626');
      els.push(<polygon key={b.id} points={pts(b.rect)} fill="none" stroke={col} strokeWidth="1.5" strokeDasharray={b.status === 'full' ? undefined : '5 3'} vectorEffect="non-scaling-stroke" />);
    });

    els.push(<polygon key="boundary-line" points={pts(result.bring)} fill="none" stroke="#0a6a6a" strokeWidth="2" strokeDasharray="6 3" vectorEffect="non-scaling-stroke" />);
    return els;
  }, [result]);

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'} font-sans flex flex-col`}>
      {/* Top Header / Navbar with Hamburger Menu */}
      <header className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 md:px-6 py-3 flex items-center justify-between gap-4 sticky top-0 z-40 shadow-sm shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200" title="Menu">
            <Menu size={20} />
          </button>
          <div className="w-9 h-9 rounded-xl bg-teal-700 text-white flex items-center justify-center font-bold shadow-inner">
            <Compass size={20} />
          </div>
          <div>
            <h1 className="text-sm md:text-base font-bold tracking-tight">Naqshadeeyaha Blocks &amp; Plots</h1>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">GIS Farm Planning &amp; Plot Generator</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={() => setDarkMode(!darkMode)} className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300">
            {darkMode ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <button onClick={useSampleData} className="hidden sm:flex px-3 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-medium shadow-sm transition-colors">
            Xogta Tusaalaha
          </button>
        </div>
      </header>

      {/* Sidebar Drawer with 3 Pages */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <div className="relative w-72 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 p-5 flex flex-col gap-6 shadow-2xl z-10">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-sm">Liiska Bogagga</h2>
              <button onClick={() => setSidebarOpen(false)} className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"><X size={18} /></button>
            </div>
            <nav className="flex flex-col gap-2">
              <button onClick={() => { setPage('map'); setSidebarOpen(false); }} className={`flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition-all ${page === 'map' ? 'bg-teal-700 text-white shadow-sm' : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'}`}>
                🗺️ Khariirad
              </button>
              <button onClick={() => { setPage('nashqado'); setSidebarOpen(false); }} className={`flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition-all ${page === 'nashqado' ? 'bg-teal-700 text-white shadow-sm' : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'}`}>
                📁 Nashqado (Kayd)
              </button>
              <button onClick={() => { setPage('setting'); setSidebarOpen(false); }} className={`flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition-all ${page === 'setting' ? 'bg-teal-700 text-white shadow-sm' : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'}`}>
                ⚙️ Setting
              </button>
            </nav>
          </div>
        </div>
      )}

      {/* PAGE 1: KHARIIRAD */}
      {page === 'map' && (
        <div className="relative flex-1 flex flex-col overflow-hidden h-[calc(100vh-65px)]">
          {/* Top Right Floating Single Export Button over Map */}
          <div className="absolute top-4 right-4 z-30">
            <div className="relative">
              <button onClick={() => setExportMenuOpen(!exportMenuOpen)} className="px-4 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-2xl text-xs font-medium flex items-center gap-2 shadow-xl transition-transform active:scale-95">
                <Download size={16} /> Export
              </button>
              {exportMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-1.5 shadow-2xl z-40 grid gap-1">
                  <button onClick={() => { handleDownloadShapefile('wgs'); setExportMenuOpen(false); }} className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 font-medium">
                    <Download size={14} /> Shapefile (.zip)
                  </button>
                  <button onClick={() => { handleDownloadGeoJSON(); setExportMenuOpen(false); }} className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 font-medium">
                    <FileText size={14} /> GeoJSON (.json)
                  </button>
                  <button onClick={() => { handleDownloadAll(); setExportMenuOpen(false); }} className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 font-medium">
                    <Download size={14} /> Dhammaan (.zip)
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Floating Bottom Center "+" Button for Importing Files */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30">
            <label className="w-14 h-14 rounded-full bg-teal-700 hover:bg-teal-800 text-white shadow-2xl cursor-pointer flex items-center justify-center transition-transform active:scale-95 border-2 border-white dark:border-slate-900" title="Soo geli fayl (Import)">
              <Plus size={28} />
              <input type="file" accept=".geojson,.json,.kml,.zip" className="hidden" onChange={e => e.target.files?.[0] && handleFileLoad(e.target.files[0])} />
            </label>
          </div>

          {/* Floating Side Tools on Map */}
          <div className="absolute right-4 bottom-24 z-30 flex flex-col gap-2 bg-white/90 dark:bg-slate-900/95 backdrop-blur border border-slate-200 dark:border-slate-800 rounded-2xl p-1.5 shadow-lg">
            <button onClick={() => zoomMap(1.3)} title="Weyneey" className="p-2.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-slate-700 dark:text-slate-200"><ZoomIn size={18} /></button>
            <button onClick={() => zoomMap(1 / 1.3)} title="Yaree" className="p-2.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-slate-700 dark:text-slate-200"><ZoomOut size={18} /></button>
            <button onClick={fitBounds} title="Dhammaan" className="p-2.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-slate-700 dark:text-slate-200"><Maximize2 size={18} /></button>
          </div>

          {/* Map Viewport Autofit */}
          <div className="flex-1 w-full h-full bg-[#f8fafb] dark:bg-[#111f25] relative">
            {result && vb ? (
              <svg ref={svgRef} viewBox={`${vb.x} ${vb.y} ${vb.w} ${vb.h}`} className="w-full h-full cursor-grab active:cursor-grabbing">
                <defs>
                  <pattern id="hat" width="3" height="3" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
                    <line x1="0" y1="0" x2="0" y2="3" stroke="#dc2626" strokeWidth="0.6" />
                  </pattern>
                </defs>
                {svgContent}
              </svg>
            ) : (
              <div className="absolute inset-0 grid place-items-center text-slate-400 text-sm">
                Fadlan soo geli xuduudka beerta ama guji &ldquo;Xogta Tusaalaha&rdquo;.
              </div>
            )}
            {info && (
              <div className="absolute left-4 bottom-6 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-3 text-xs font-mono shadow-xl flex items-center gap-3 z-30">
                <span>{info}</span>
                <button onClick={() => setInfo(null)} className="text-slate-400 hover:text-slate-600 font-bold">✕</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* PAGE 2: NASHQADO (KAYD & REPORTS) */}
      {page === 'nashqado' && (
        <div className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full grid gap-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <h2 className="text-lg font-bold mb-1">Kaydka Nashqadaha (Saved Designs &amp; Reports)</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">Maaree faylasha la soo geliyey, aragna warbixinta guud ee blocks-ka iyo plots-ka la dhisay.</p>

            {result && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-200 dark:border-slate-700">
                  <div className="text-xs text-slate-500">Blocks Guud</div>
                  <div className="text-xl font-mono font-bold mt-1 text-teal-700 dark:text-teal-400">{result.blocks.length}</div>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-200 dark:border-slate-700">
                  <div className="text-xs text-slate-500">Plots Buuxa</div>
                  <div className="text-xl font-mono font-bold mt-1">{result.plots.length}</div>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-200 dark:border-slate-700">
                  <div className="text-xs text-slate-500">Aagga Beerta</div>
                  <div className="text-xl font-mono font-bold mt-1">{(result.barea / 1e4).toFixed(2)} ha</div>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-200 dark:border-slate-700">
                  <div className="text-xs text-slate-500">Jiheynta</div>
                  <div className="text-xl font-mono font-bold mt-1">{(result.angle || 0).toFixed(1)}°</div>
                </div>
              </div>
            )}

            {result && result.blocks.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-400 uppercase font-semibold">
                      <th className="pb-3 px-3">Block ID</th>
                      <th className="pb-3 px-3">Xaalad</th>
                      <th className="pb-3 px-3">Plots buuxa</th>
                      <th className="pb-3 px-3">Half-plots</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.blocks.map((b: any) => (
                      <tr key={b.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="py-3 px-3 font-mono font-bold text-teal-700 dark:text-teal-400">{b.id}</td>
                        <td className="py-3 px-3">{b.status}</td>
                        <td className="py-3 px-3 font-mono">{b.nf} / {b.total}</td>
                        <td className="py-3 px-3 font-mono">{b.nh}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-xs text-slate-400">Nashqad la kaydiyey ama block la dhisay ma jiro.</p>
            )}
          </div>
        </div>
      )}

      {/* PAGE 3: SETTING */}
      {page === 'setting' && (
        <div className="flex-1 p-4 md:p-8 max-w-3xl mx-auto w-full grid gap-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm grid gap-6">
            <div>
              <h2 className="text-lg font-bold mb-1">Dejinta Cabbirrada &amp; Waddooyinka Gaarka ah</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">Hagaaji cabbirka block-ka, plots-ka, iyo waddooyinka u dhexeeya safafka ama columns-ka.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-slate-600 dark:text-slate-400 mb-1 block font-medium">Block: Dherer (Length in m)</label>
                <input type="number" value={bL} onChange={e => setBL(Number(e.target.value))} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 font-mono text-sm" />
              </div>
              <div>
                <label className="text-slate-600 dark:text-slate-400 mb-1 block font-medium">Block: Ballac (Width in m)</label>
                <input type="number" value={bW} onChange={e => setBW(Number(e.target.value))} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 font-mono text-sm" />
              </div>
              <div>
                <label className="text-slate-600 dark:text-slate-400 mb-1 block font-medium">Plot: Ballac</label>
                <input type="number" value={pW} onChange={e => setPW(Number(e.target.value))} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 font-mono text-sm" />
              </div>
              <div>
                <label className="text-slate-600 dark:text-slate-400 mb-1 block font-medium">Plot: Dhexe (Depth)</label>
                <input type="number" value={pD} onChange={e => setPD(Number(e.target.value))} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 font-mono text-sm" />
              </div>
              <div>
                <label className="text-slate-600 dark:text-slate-400 mb-1 block font-medium">Waddo (Rows u dhexeysa)</label>
                <input type="number" value={rU} onChange={e => { setRU(Number(e.target.value)); if (rLink) setRV(Number(e.target.value)); }} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 font-mono text-sm" />
              </div>
              <div>
                <label className="text-slate-600 dark:text-slate-400 mb-1 block font-medium">Waddo (Columns u dhexeysa)</label>
                <input type="number" value={rV} onChange={e => setRV(Number(e.target.value))} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 font-mono text-sm" />
              </div>
              <div className="sm:col-span-2 flex items-center gap-2 mt-1">
                <input type="checkbox" checked={rLink} onChange={e => setRLink(e.target.checked)} id="rLink" className="accent-teal-700 w-4 h-4" />
                <label htmlFor="rLink" className="cursor-pointer text-xs font-medium">Labada waddo isku cabbir ha ahaadaan</label>
              </div>
            </div>

            {/* Special Road Configuration */}
            <div className="border-t border-slate-200 dark:border-slate-800 pt-4 mt-2">
              <h3 className="text-sm font-bold mb-2">Waddo Gaar ah (Ballac kale oo hal waddo ah)</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="text-slate-500 mb-1 block">Axis</label>
                  <select value={specialRoadAxis} onChange={e => setSpecialRoadAxis(e.target.value)} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5">
                    <option value="R">U dhexeysa Rows (Row)</option>
                    <option value="C">U dhexeysa Columns (Column)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-500 mb-1 block">Lambarka (Index)</label>
                  <input type="number" min="0" value={specialRoadIndex} onChange={e => setSpecialRoadIndex(Number(e.target.value))} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono" />
                </div>
                <div>
                  <label className="text-slate-500 mb-1 block">Ballaca (mitir)</label>
                  <input type="number" min="0" value={specialRoadWidth} onChange={e => setSpecialRoadWidth(Number(e.target.value))} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono" />
                </div>
              </div>
              <button onClick={addSpecialRoad} className="mt-3 px-4 py-2 bg-teal-700 text-white rounded-xl text-xs font-semibold hover:bg-teal-800">
                Ku dar waddada gaarka ah
              </button>

              {roads.length > 0 && (
                <ul className="mt-3 text-xs text-slate-500 list-disc pl-4 space-y-1">
                  {roads.map((z, idx) => (
                    <li key={idx}>Waddada {z.axis === 'R' ? 'Row' : 'Column'} #{z.j} — ballac {z.w} m</li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}

      {/* POP-UP MODAL ON FILE IMPORT */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm grid place-items-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl grid gap-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-teal-700 dark:text-teal-400">Xuduudka La Soo Geliyey ✅</h3>
              <button onClick={() => setShowImportModal(false)} className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Faylka <b>{pendingFileName}</b> waxaa loo akhriyey si guul leh. Fadlan xaqiiji ama hagaaji cabbirrada beerta iyo block-ka tusaalaha hoos ku qoran:
            </p>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-500 mb-1 block">Block Dherer (m)</label>
                <input type="number" value={bL} onChange={e => setBL(Number(e.target.value))} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2 font-mono" />
              </div>
              <div>
                <label className="text-slate-500 mb-1 block">Block Ballac (m)</label>
                <input type="number" value={bW} onChange={e => setBW(Number(e.target.value))} className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2 font-mono" />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-2">
              <button onClick={() => setShowImportModal(false)} className="px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-semibold shadow-sm">
                Xaqiiji oo Naqshadee
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
