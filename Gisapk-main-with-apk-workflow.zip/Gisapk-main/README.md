# Naqshadeeyaha Blocks & Plots (React Web Application)

A fully featured web application for farm block and plot drafting, GIS polygon clipping, UTM projection, and GeoJSON/Shapefile/PDF export in Somali, rewritten as a modern React SPA with TypeScript and Tailwind CSS.

## Features
- **File Management**: Upload boundary GeoJSON, sample block, and special areas, or load built-in sample data.
- **Dimensions & Configuration**: Adjust block length, plot width, row and column spacing, rotation, and custom special road widths.
- **Interactive SVG Map**: Pan, zoom, inspect parcel details, view Block IDs and Plot IDs.
- **Statistics & Tables**: Comprehensive acreage and plot statistics, sortable blocks table.
- **Exports**: Download Shapefile (.zip), GeoJSON (.json), CSV, and vector PDF maps.

## Development
- Run dev server: `npm run dev` (port 3000)
- Build for production: `npm run build`

